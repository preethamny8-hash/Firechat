const $ = (id) => document.getElementById(id);
const state = { chatId: null, image: null, controller: null, busy: false, lastUserText: "" };
const messagesEl = $("messages");
const input = $("messageInput");

marked.setOptions({ breaks: true, gfm: true });

async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function safeMarkdown(value) {
  const raw = marked.parse(value || "");
  const template = document.createElement("template");
  template.innerHTML = raw;
  template.content.querySelectorAll("script,style,iframe,object,embed,form").forEach(n => n.remove());
  template.content.querySelectorAll("*").forEach(el => {
    [...el.attributes].forEach(attr => {
      if (attr.name.startsWith("on") || (["href","src"].includes(attr.name) && /^\s*javascript:/i.test(attr.value))) el.removeAttribute(attr.name);
    });
  });
  return template.innerHTML;
}
function scrollBottom() { $("chatScroll").scrollTop = $("chatScroll").scrollHeight; }
function showWelcome(show) { $("welcome").hidden = !show; }
function setBusy(busy) {
  state.busy = busy;
  $("thinking").hidden = !busy;
  $("sendBtn").disabled = false;
  $("sendBtn").title = busy ? "Stop generating" : "Send message";
  $("sendBtn").setAttribute("aria-label", busy ? "Stop generating" : "Send message");
  $("sendBtn").innerHTML = busy ? "■" : "<span>↑</span>";
  input.disabled = busy;
  scrollBottom();
}
function renderMessage(message) {
  const isUser = message.role === "user";
  const node = document.createElement("article");
  node.className = `message ${isUser ? "user" : "assistant"}`;
  const avatar = isUser ? "Y" : "✦";
  const content = isUser ? `<div>${escapeHTML(message.content).replace(/\n/g,"<br>")}</div>` : safeMarkdown(message.content);
  node.innerHTML = `<div class="avatar">${avatar}</div><div class="message-body"><div class="bubble">${content}</div>${!isUser ? `<div class="message-tools"><button class="copy-response">▢ Copy</button><button class="regen">↻ Regenerate</button></div>` : ""}</div>`;
  if (!isUser) {
    node.querySelectorAll("pre code").forEach(block => {
      hljs.highlightElement(block);
      const pre = block.parentElement;
      const wrap = document.createElement("div");
      wrap.className = "code-wrap";
      const lang = [...block.classList].find(c => c.startsWith("language-"))?.replace("language-","") || "CODE";
      wrap.innerHTML = `<div class="code-head"><span>${escapeHTML(lang.toUpperCase())}</span><button class="copy-code">▢ Copy code</button></div>`;
      pre.parentNode.insertBefore(wrap, pre);
      wrap.appendChild(pre);
      wrap.querySelector(".copy-code").addEventListener("click", () => copyText(block.innerText));
    });
    node.querySelector(".copy-response").addEventListener("click", () => copyText(message.content));
    node.querySelector(".regen").addEventListener("click", regenerate);
  }
  messagesEl.appendChild(node);
  scrollBottom();
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch { const el=document.createElement("textarea");el.value=text;document.body.appendChild(el);el.select();document.execCommand("copy");el.remove(); }
}
async function refreshHistory() {
  const chats = await api("/api/chats");
  const list = $("historyList"); list.innerHTML = "";
  chats.forEach(chat => {
    const item = document.createElement("div");
    item.className = "history-item" + (chat.id === state.chatId ? " active" : "");
    item.innerHTML = `<span>▤</span><span class="history-title">${escapeHTML(chat.title)}</span><button class="delete-chat" title="Delete conversation" aria-label="Delete conversation">×</button>`;
    item.addEventListener("click", e => { if (!e.target.closest(".delete-chat")) openChat(chat.id); });
    item.querySelector(".delete-chat").addEventListener("click", async e => {
      e.stopPropagation();
      if (!confirm("Delete this conversation permanently?")) return;
      await api(`/api/chats/${chat.id}`, {method:"DELETE"});
      if (state.chatId === chat.id) await newChat();
      else await refreshHistory();
    });
    list.appendChild(item);
  });
}
async function newChat() {
  if (state.controller) state.controller.abort();
  setBusy(false);
  const data = await api("/api/chats", {method:"POST"});
  state.chatId = data.id; state.lastUserText = "";
  messagesEl.innerHTML = ""; showWelcome(true); clearImage();
  await refreshHistory(); closeMenu();
  input.focus();
}
async function openChat(id) {
  if (state.controller) state.controller.abort();
  setBusy(false);
  const data = await api(`/api/chats/${id}`);
  state.chatId = id; state.lastUserText = "";
  messagesEl.innerHTML = "";
  data.messages.forEach(renderMessage);
  showWelcome(data.messages.length === 0);
  await refreshHistory(); closeMenu(); scrollBottom();
}
function clearImage() {
  state.image = null; $("imageInput").value = ""; $("attachmentPreview").hidden = true;
}
function addUserPreview(text, image) {
  renderMessage({role:"user",content:text || "Please describe and explain this image."});
  if (image) {
    const last = messagesEl.lastElementChild.querySelector(".bubble");
    const img = document.createElement("img");
    img.src = URL.createObjectURL(image); img.alt = "Attached image";
    img.style.cssText = "display:block;max-width:220px;max-height:180px;object-fit:cover;border-radius:9px;margin-top:8px";
    last.appendChild(img);
  }
}
async function sendMessage(textOverride = null, imageOverride = null) {
  if (state.busy) return;
  const text = (textOverride ?? input.value).trim();
  const image = imageOverride ?? state.image;
  if (!text && !image) return;
  if (!state.chatId) await newChat();
  state.lastUserText = text;
  showWelcome(false); addUserPreview(text, image); clearImage();
  input.value = ""; input.style.height = "auto";
  const form = new FormData(); form.append("message", text);
  if (image) form.append("image", image, image.name);
  const controller = new AbortController(); state.controller = controller;
  setBusy(true);
  try {
    const result = await api(`/api/chats/${state.chatId}/messages`, {method:"POST",body:form,signal:controller.signal});
    renderMessage(result.message);
    await refreshHistory();
  } catch (err) {
    if (err.name !== "AbortError") {
      renderMessage({role:"assistant",content:`**Couldn't send that message.** ${err.message}`});
    }
  } finally {
    if (state.controller === controller) state.controller = null;
    setBusy(false); input.disabled = false; input.focus();
  }
}
async function regenerate() {
  if (state.busy || !state.chatId) return;
  // Remove the latest assistant reply and its preceding user turn, then resubmit the same prompt.
  const chat = await api(`/api/chats/${state.chatId}`);
  const msgs = chat.messages;
  const lastAssistant = [...msgs].reverse().find(m => m.role === "assistant");
  const lastUser = [...msgs].reverse().find(m => m.role === "user");
  if (!lastAssistant || !lastUser) return;
  // Rebuild earlier turns in a fresh session, then request the final turn again.
  const earlier = msgs.slice(0, msgs.indexOf(lastUser));
  messagesEl.innerHTML = "";
  for (const m of earlier) renderMessage(m);
  // Persist earlier messages are restored through a dedicated internal endpoint? Instead use a fresh chat to avoid inconsistent context.
  const oldId = state.chatId;
  const fresh = await api("/api/chats",{method:"POST"});
  state.chatId = fresh.id;
  messagesEl.innerHTML = "";
  for (const m of earlier) {
    // Replay turns in order so the model context and database remain aligned.
    if (m.role === "user") {
      await sendMessage(m.content);
    } else {
      // Earlier assistant messages are recreated by the model during replay of their user turns.
    }
  }
  await sendMessage(lastUser.content);
  await api(`/api/chats/${oldId}`,{method:"DELETE"}).catch(()=>{});
}
async function clearCurrentChat() {
  if (!state.chatId) return;
  if (!confirm("Clear all messages in this conversation?")) return;
  await api(`/api/chats/${state.chatId}/messages`,{method:"DELETE"});
  messagesEl.innerHTML="";showWelcome(true);state.lastUserText="";await refreshHistory();
}
function closeMenu() { $("sidebar").classList.remove("open"); $("scrim").classList.remove("show"); }
function openMenu() { $("sidebar").classList.add("open"); $("scrim").classList.add("show"); }

$("newChat").addEventListener("click",newChat);
$("topNew").addEventListener("click",newChat);
$("clearChat").addEventListener("click",clearCurrentChat);
$("menuToggle").addEventListener("click",openMenu);
$("closeSidebar").addEventListener("click",closeMenu);
$("scrim").addEventListener("click",closeMenu);
$("chatForm").addEventListener("submit",e=>{e.preventDefault();if(state.busy){if(state.controller)state.controller.abort();return;}sendMessage();});
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,180)+"px";});
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage();}});
$("attachBtn").addEventListener("click",()=>$("imageInput").click());
$("imageInput").addEventListener("change",e=>{
  const file=e.target.files[0];if(!file)return;
  if(!["image/png","image/jpeg","image/webp"].includes(file.type)||file.size>7*1024*1024){alert("Choose a PNG, JPEG, or WebP image smaller than 7 MB.");e.target.value="";return;}
  state.image=file;$("previewImage").src=URL.createObjectURL(file);$("previewName").textContent=file.name;$("attachmentPreview").hidden=false;
});
$("removeImage").addEventListener("click",clearImage);
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>{input.value=b.dataset.prompt;input.focus();sendMessage();}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeMenu();});
(async()=>{try{await refreshHistory();const chats=await api("/api/chats");if(chats.length)await openChat(chats[0].id);else await newChat();}catch(e){renderMessage({role:"assistant",content:`Unable to start Fire Chat: ${e.message}`});}})();
